package com.epam.training.jp.jdbc.excercises.dao;

public interface MenuFoodDao {

	void removeMenuFoods(int id);
}
