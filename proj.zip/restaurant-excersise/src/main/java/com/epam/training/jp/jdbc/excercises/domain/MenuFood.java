package com.epam.training.jp.jdbc.excercises.domain;

public class MenuFood {

	private int menuId;
	private int foodId;

	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	
	
}
