package com.epam.training.jp.jdbc.excercises.dao;

public interface MenuDao {

	void removeMenu(int id);
}
