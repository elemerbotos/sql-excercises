package com.epam.training.jp.jdbc.excercises.dao;

import com.epam.training.jp.jdbc.excercises.domain.Address;

public interface AddressDao {

	void save(Address address);
	
	
}
