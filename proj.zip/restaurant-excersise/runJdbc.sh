mvn compile exec:java -Dexec.mainClass=com.epam.training.jp.JdbcApp
